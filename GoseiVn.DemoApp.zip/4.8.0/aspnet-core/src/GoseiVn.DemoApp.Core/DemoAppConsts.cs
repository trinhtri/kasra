﻿namespace GoseiVn.DemoApp
{
    public class DemoAppConsts
    {
        public const string LocalizationSourceName = "DemoApp";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
